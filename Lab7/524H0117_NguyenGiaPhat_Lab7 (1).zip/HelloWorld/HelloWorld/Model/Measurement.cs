﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace HelloWorld.Model
{
    public class Measurement
    {
        public int MeasurementId { get; set; }
        public string? MeasurementName { get; set; }
        public string? MeasurementUnit { get; set; }

        public List<Measurement> GetMeasurmentParameters(string connectionString)
        {
            List<Measurement> list = new List<Measurement>();

            SqlConnection con = new SqlConnection(connectionString);
            string sql = "SELECT MeasurementId, MeasurementName, Unit FROM MEASUREMENT";

            con.Open();

            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Measurement m = new Measurement();
                m.MeasurementId = Convert.ToInt32(dr["MeasurementId"]);
                m.MeasurementName = dr["MeasurementName"]?.ToString();
                m.MeasurementUnit = dr["Unit"]?.ToString();

                list.Add(m);
            }

            return list;
        }

        public void Insert(string connectionString)
        {
            SqlConnection con = new SqlConnection(connectionString);
            string sql = "INSERT INTO MEASUREMENT(MeasurementName, Unit) VALUES(@name, @unit)";

            con.Open();

            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@name", MeasurementName ?? "");
            cmd.Parameters.AddWithValue("@unit", MeasurementUnit ?? "");

            cmd.ExecuteNonQuery();
        }

        public void Delete(int id, string connectionString)
        {
            SqlConnection con = new SqlConnection(connectionString);
            string sql = "DELETE FROM MEASUREMENT WHERE MeasurementId=@id";

            con.Open();

            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@id", id);

            cmd.ExecuteNonQuery();
        }

        public void Update(string connectionString)
        {
            SqlConnection con = new SqlConnection(connectionString);
            string sql = "UPDATE MEASUREMENT SET MeasurementName=@name, Unit=@unit WHERE MeasurementId=@id";

            con.Open();

            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@name", MeasurementName ?? "");
            cmd.Parameters.AddWithValue("@unit", MeasurementUnit ?? "");
            cmd.Parameters.AddWithValue("@id", MeasurementId);

            cmd.ExecuteNonQuery();
        }
    }
}