using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using HelloWorld.Model;

namespace HelloWorld.Pages
{
    public class MeasurementModel : PageModel
    {
        private readonly IConfiguration _config;

        public List<Measurement> list = new List<Measurement>();

        public MeasurementModel(IConfiguration config)
        {
            _config = config;
        }

        public void OnGet()
        {
            string conn = _config.GetConnectionString("ConnectionString");

            Measurement m = new Measurement();
            list = m.GetMeasurmentParameters(conn);
        }
    }
}