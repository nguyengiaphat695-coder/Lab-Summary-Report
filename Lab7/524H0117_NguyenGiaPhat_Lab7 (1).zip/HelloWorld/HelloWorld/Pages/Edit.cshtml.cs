using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using HelloWorld.Model;
using System.Linq;

namespace HelloWorld.Pages
{
    public class EditModel : PageModel
    {
        private readonly IConfiguration _config;

        [BindProperty]
        public Measurement? m { get; set; }

        public EditModel(IConfiguration config)
        {
            _config = config;
        }

        public void OnGet(int id)
        {
            string? conn = _config.GetConnectionString("ConnectionString");

            if (conn == null) return;

            Measurement temp = new Measurement();
            var list = temp.GetMeasurmentParameters(conn);

            m = list.FirstOrDefault(x => x.MeasurementId == id);

           
            if (m == null)
            {
                m = new Measurement();
            }
        }

        public IActionResult OnPost()
        {
            string? conn = _config.GetConnectionString("ConnectionString");

            if (conn == null || m == null)
            {
                return Page();
            }

            m.Update(conn);

            return RedirectToPage("Measurement");
        }
    }
}