using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using HelloWorld.Model;

namespace HelloWorld.Pages
{
    public class DeleteModel : PageModel
    {
        private readonly IConfiguration _config;

        public DeleteModel(IConfiguration config)
        {
            _config = config;
        }

        public IActionResult OnGet(int id)
        {
            string conn = _config.GetConnectionString("ConnectionString");

            Measurement m = new Measurement();
            m.Delete(id, conn);

            return RedirectToPage("Measurement");
        }
    }
}