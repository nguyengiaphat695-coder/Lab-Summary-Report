using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using HelloWorld.Model;

namespace HelloWorld.Pages
{
    public class CreateModel : PageModel
    {
        private readonly IConfiguration _config;

        [BindProperty]
        public Measurement m { get; set; }

        public CreateModel(IConfiguration config)
        {
            _config = config;
        }

        public void OnGet() { }

        public IActionResult OnPost()
        {
            string conn = _config.GetConnectionString("ConnectionString");

            m.Insert(conn);

            return RedirectToPage("Measurement");
        }
    }
}