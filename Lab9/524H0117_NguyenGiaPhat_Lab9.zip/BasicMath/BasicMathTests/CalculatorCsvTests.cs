﻿using CsvHelper;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using Xunit;
using BasicMath;

namespace BasicMathTests
{
    public class CalculatorCsvTests
    {
        public static IEnumerable<object[]> GetTestData(string fileName)
        {
            using (var reader = new StreamReader(fileName))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                foreach (var record in csv.GetRecords<TestData>())
                {
                    yield return new object[]
                    {
                        record.A,
                        record.B,
                        record.Expected
                    };
                }
            }
        }

        [Theory]
        [MemberData(nameof(GetTestData), parameters: "add_testdata.csv")]

        public void Add_CsvData_ReturnsCorrectSum(
            int a,
            int b,
            double expected)
        {
            BasicMaths calculator = new BasicMaths();

            double result = calculator.Add(a, b);

            Assert.Equal(expected, result);
        }

        public class TestData
        {
            public int A { get; set; }

            public int B { get; set; }

            public double Expected { get; set; }
        }
    }
}