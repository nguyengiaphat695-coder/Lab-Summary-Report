﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BasicMath;

namespace BasicMathTests
{
    [TestClass]
    public class BasicMathsTests
    {
        [DataTestMethod]

        [DataRow(1, 1, 2)]
        [DataRow(-1, -1, -2)]
        [DataRow(0, 0, 0)]
        [DataRow(int.MaxValue, 1, (double)int.MaxValue + 1)]
        [DataRow(int.MinValue, -1, (double)int.MinValue - 1)]

        public void Test_AddMV(int a, int b, double expected)
        {
            BasicMaths bm = new BasicMaths();

            double actual = bm.Add(a, b);

            Assert.AreEqual(expected, actual);
        }
    }
}