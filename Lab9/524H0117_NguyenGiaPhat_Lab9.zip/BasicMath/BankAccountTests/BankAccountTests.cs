﻿using Xunit;
using BankAccountApp;
using System;

namespace BankAccountTests
{
    public class BankAccountTests
    {
        [Theory]
        [InlineData("John Doe", 1000, 200, 800)]

        public void Debit_ValidAmount_UpdatesBalance(
            string customerName,
            decimal initialBalance,
            decimal debitAmount,
            decimal expectedBalance)
        {
            var account = new BankAccount(
                customerName,
                initialBalance);

            account.Debit(debitAmount);

            Assert.Equal(expectedBalance, account.Balance);
        }

        [Theory]
        [InlineData("Bob Brown", 100, 150)]

        public void Debit_InsufficientFunds_ThrowsException(
            string customerName,
            decimal initialBalance,
            decimal debitAmount)
        {
            var account = new BankAccount(
                customerName,
                initialBalance);

            Assert.Throws<InvalidOperationException>(() =>
                account.Debit(debitAmount));
        }
    }
}