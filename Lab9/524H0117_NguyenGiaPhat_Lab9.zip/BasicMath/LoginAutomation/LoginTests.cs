﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using CsvHelper;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using Xunit;

namespace LoginAutomation
{
    public class LoginTests
    {
        public static IEnumerable<object[]> GetTestData()
        {
            using (var reader =
                new StreamReader("LoginTestData.csv"))

            using (var csv =
                new CsvReader(reader,
                CultureInfo.InvariantCulture))
            {
                foreach (var record in
                    csv.GetRecords<TestData>())
                {
                    yield return new object[]
                    {
                        record.Username,
                        record.Password
                    };
                }
            }
        }

        [Theory]
        [MemberData(nameof(GetTestData))]

        public void Login_WithValidCredentials_ShouldSucceed(
            string username,
            string password)
        {
            using (IWebDriver driver =
                new ChromeDriver())
            {
                driver.Navigate().GoToUrl(
                    "file:///C:/Nam2 HK2/CNPM/ThucHanh/lAB9/BasicMath/LoginAutomation/login.html"
                );

                driver.FindElement(By.Id("username"))
                    .SendKeys(username);

                driver.FindElement(By.Id("password"))
                    .SendKeys(password);

                driver.FindElement(By.Id("loginButton"))
                    .Click();

                System.Threading.Thread.Sleep(10000);
            }
        }

        public class TestData
        {
            public string Username { get; set; }

            public string Password { get; set; }
        }
    }
}