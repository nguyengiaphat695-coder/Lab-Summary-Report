﻿CREATE DATABASE SchoolDB;
GO
USE SchoolDB;
CREATE TABLE tblUsers (
    UserID INT IDENTITY PRIMARY KEY,
    Username NVARCHAR(50),
    Password NVARCHAR(50)
);

INSERT INTO tblUsers VALUES
('admin','123'),
('user1','111');

CREATE TABLE tblStudents
(
    StudentID INT IDENTITY PRIMARY KEY,
    Name NVARCHAR(100),
    Class NVARCHAR(50)
);

INSERT INTO tblStudents VALUES
(N'Nguyễn Văn A', '12A1'),
(N'Trần Thị B', '12A2');
