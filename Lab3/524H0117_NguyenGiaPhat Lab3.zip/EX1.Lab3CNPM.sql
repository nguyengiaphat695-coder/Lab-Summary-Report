USE Lab3DB;
GO

CREATE TABLE Customers (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100),
    Email NVARCHAR(100)
);

INSERT INTO Customers VALUES
('John Doe','john@tdtu.edu.vn'),
('Jane Smith','jane@tdtu.edu.vn'),
('Nguyen Van A','a@tdtu.edu.vn');
SELECT * FROM Customers;