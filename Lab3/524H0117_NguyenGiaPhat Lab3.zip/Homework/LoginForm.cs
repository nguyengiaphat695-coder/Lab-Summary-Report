﻿using System;
using System.Windows.Forms;
using BLL;

namespace UI
{
    public partial class LoginForm : Form
    {
        UserBLL bll = new UserBLL();

        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (bll.Login(txtUsername.Text, txtPassword.Text))
            {
                this.Hide();
                MainForm f = new MainForm();
                f.Show();
            }
            else
            {
                MessageBox.Show("Sai tài khoản!");
            }
        }

        
        private void LoginForm_Load(object sender, EventArgs e)
        {
            
        }
    }
}

namespace BLL
{
    public class UserBLL
    {
        public bool Login(string username, string password)
        {
            // Implement your login logic here
            return username == "admin" && password == "password";
        }
    }
}
