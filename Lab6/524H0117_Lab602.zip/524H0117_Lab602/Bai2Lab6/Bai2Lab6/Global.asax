﻿<%@ Application Codebehind="Global.asax.cs" Inherits="Bai2Lab6.MvcApplication" Language="C#" %>
