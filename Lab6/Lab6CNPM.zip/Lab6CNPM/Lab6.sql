CREATE DATABASE SchoolDB123;
CREATE TABLE Departments (
    DepartmentID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(50),
    Budget DECIMAL(8,2),
    StartDate DAT1E
);

CREATE TABLE Instructors (
    InstructorID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    HireDate DATE
);

CREATE TABLE Courses (
    CourseID INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(100),
    Credits INT,
    DepartmentID INT FOREIGN KEY REFERENCES Departments(DepartmentID)
);

CREATE TABLE Students (
    StudentID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    EnrollmentDate DATE
);

CREATE TABLE Enrollments (
    EnrollmentID INT PRIMARY KEY IDENTITY(1,1),
    CourseID INT,
    StudentID INT,
    Grade DECIMAL(3,2)
);
INSERT INTO Departments VALUES ('IT', 100000, '2023-01-01');
INSERT INTO Instructors VALUES ('A', 'Nguyen', '2022-01-01');
INSERT INTO Courses VALUES ('Lap trinh C', 3, 1);
INSERT INTO Students VALUES ('B', 'Tran', '2023-09-01');
INSERT INTO Enrollments VALUES (1,1,8.5);
SELECT * FROM INFORMATION_SCHEMA.TABLES;