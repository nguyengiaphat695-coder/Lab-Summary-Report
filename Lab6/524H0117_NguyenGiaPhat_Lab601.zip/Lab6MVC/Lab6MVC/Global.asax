﻿<%@ Application Codebehind="Global.asax.cs" Inherits="Lab6MVC.MvcApplication" Language="C#" %>
