CREATE DATABASE LabDB
GO

USE LabDB
GO

CREATE TABLE Customers
(
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100),
    Email NVARCHAR(100)
)
GO

INSERT INTO Customers (Name, Email)
VALUES 
('John Doe', 'john.doe@tdtu.com'),
('Jane Smith', 'jane.smith@tdtu.com'),
('Trung Pham', 'trung.pham@tdtu.com'),
('Emily Davis', 'emily.davis@tdtu.com'),
('Thai Pham', 'thai.pham@etdtu.com')
GO

SELECT * FROM Customers
GO